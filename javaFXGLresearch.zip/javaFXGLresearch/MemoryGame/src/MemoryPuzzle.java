import com.almasb.fxgl.app.GameApplication;
import com.almasb.fxgl.app.GameSettings;
import com.almasb.fxgl.app.scene.FXGLMenu;
import com.almasb.fxgl.app.scene.SceneFactory;

import javafx.event.Event;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

import com.almasb.fxgl.dsl.EntityBuilder;
import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.Entity;

import javafx.animation.FadeTransition;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MemoryPuzzle extends GameApplication {

    // variables used elsewhere, accessable to other methods
    private static final int NUM_OF_PAIRS = 10; // total numbers of pairs, can be increased for harder difficulty
    private static final int NUM_PER_ROW = 5;   // number of cards per row, can be increased for wider screens
    private Tile selected = null;               // tile object, keeps track of the cards the user has clicked on
    private int clickCounter = 2;               // number of clicks at a time, to limit user input
    private int scoreTracker = 0;               // used to keep track of score, could be replaced using FXGL.geti() and someother call if enough time
    private int streakCounter = 0;              // keeps track of the streak (used for calculating score), same as above
    private int maxStreak = 0;                  // keeps track of the highest streak the player gets

    @Override
    protected void initSettings(GameSettings settings) {    // sets basics up, ie., screen size, window title, etc. 
        settings.setWidth(800);
        settings.setHeight(800);
        settings.setTitle("The Memory Game");
        settings.setVersion("0.0.1");
        settings.setMainMenuEnabled(true);
        settings.setSceneFactory(new SceneFactory() {
            @Override
            public FXGLMenu newMainMenu() {
                return new MemoryMainMenu();
            }
        });
    }

    private void initCards() {      // initializes the cards as objects, prints them out, all the fun stuff
        int numCard = 1;
        List<Tile> tiles = new ArrayList<>();
        for (int i = 0; i < NUM_OF_PAIRS; i++) {
            tiles.add(new Tile(String.valueOf(numCard)));
            tiles.add(new Tile(String.valueOf(numCard)));
            numCard++;
        }

        Collections.shuffle(tiles);

        for (int i = 0; i < tiles.size(); i++) {
            Tile tile = tiles.get(i);
            FXGL.entityBuilder()
            .at(100*(i % NUM_PER_ROW), 100*(i / NUM_PER_ROW))
            .view(tile)
            .buildAndAttach();
        }
    }

    // Sets up the tile object and how it looks, also that it can be interacted with via mouse clicks
    private class Tile extends StackPane {
        private Text text = new Text();

        public Tile(String value) {
            Rectangle border = new Rectangle(100,100);
            border.setFill(null);
            border.setStroke(Color.BLACK);
            border.setStrokeWidth(2);

            text.setText(value);
            text.setFont(Font.font(40));
            text.setFill(Color.BLUE);
            setAlignment(Pos.CENTER);
            getChildren().addAll(border, text);

            setOnMouseClicked(this::handleClick);
            hide();
        }

        // logic for how mouse clicks should be handeled. The matching game logic is here
        public void handleClick(MouseEvent event) {
            if (isFlip() || clickCounter == 0)
                    return;
                
            clickCounter--;
            if (selected == null) {
                    FXGL.play("flip.wav");
                    selected = this;
                    flip(() -> {});
            } else {
                flip(() -> {    // Case for if the cards don't match
                    if (!doesMatch(selected)) {
                        FXGL.play("wilhelm.wav");
                        selected.hide();
                        this.hide();
                        int decStreak = -1 * streakCounter;
                        FXGL.inc("streak", decStreak);
                        streakCounter = 0;
                        scoreTracker -= 100;
                        if (scoreTracker >= 0) {
                            FXGL.inc("score", -100);
                        }  else if (scoreTracker < 0) {
                            scoreTracker = 0;
                        }
                        // Case for if the cards match
                    } else {
                        FXGL.play("match.wav");
                        streakCounter ++;
                        if (maxStreak < streakCounter) {
                            int streakDiff = streakCounter - maxStreak;
                            FXGL.inc("maxStreak", streakDiff);
                            maxStreak = streakCounter;
                        }
                        FXGL.inc("streak", 1);
                        scoreTracker += streakCounter * 100;
                        FXGL.inc("score", (streakCounter * 100));
                        FXGL.inc("pairsRem", -1);
                        if (FXGL.geti("pairsRem") == 0) {
                            gameOver();
                        }
                    }

                    selected = null;
                    clickCounter = 2;
                });
            }
        }

        // Returns the value of the opacity of the card (checks if card has been flipped or not)
        public boolean isFlip() {
            return text.getOpacity() == 1;
        }

        // Changes opacity of the card so that the letter shows up
        public void flip(Runnable action) {
            FadeTransition ft = new FadeTransition(Duration.seconds(0.5), text);
            ft.setToValue(1);
            ft.setOnFinished(e -> action.run());
            ft.play();
        }
    
        // Changes opacity of the card so the letter is hidden
        public void hide() {
            FadeTransition ft = new FadeTransition(Duration.seconds(1.0), text);
            ft.setToValue(0);       
            ft.play();
        }

        // Checks if tiles are matching
        public boolean doesMatch(Tile second) {
            return text.getText().equals(second.text.getText());
        }
    }

    // Initializes values used for FXGL functions, useful because of the auto updates
    @Override
    protected void initGameVars(Map<String, Object> vars) {
        vars.put("score", 0);
        vars.put("streak", 0);
        vars.put("maxStreak", 0);
        vars.put("pairsRem", 10);
    }

    // Sets up the text that appears on screen during the game
    @Override
    protected void initUI() {
        Label scoreLabel = new Label();
        scoreLabel.setTextFill(Color.BLACK);
        scoreLabel.setFont(Font.font(30));
        scoreLabel.textProperty().bind(FXGL.getip("score").asString("Score: %d"));
        FXGL.addUINode(scoreLabel, 5, 400);

        Label streakLabel = new Label();
        streakLabel.setTextFill(Color.GOLD);
        streakLabel.setFont(Font.font(30));
        streakLabel.textProperty().bind(FXGL.getip("streak").asString("Match Streak: %d"));
        FXGL.addUINode(streakLabel, 5, 450);

        Label maxStreakLabel = new Label();
        maxStreakLabel.setTextFill(Color.BLUEVIOLET);
        maxStreakLabel.setFont(Font.font(30));
        maxStreakLabel.textProperty().bind(FXGL.getip("maxStreak").asString("Max Streak: %d"));
        FXGL.addUINode(maxStreakLabel, 5, 500);

    }

    // Method used when the game is finished
    private void gameOver() {
        FXGL.play("done.wav");
        StringBuilder bob = new StringBuilder();
        bob.append("Round Completed\n\n")
            .append("Final Score: ")
            .append(FXGL.geti("score"))
            .append("\nMax Streak: ")
            .append(FXGL.geti("maxStreak"));
        FXGL.getDialogService().showMessageBox(bob.toString(), () -> FXGL.getGameController().gotoMainMenu());
    }

    // Initializes the game, beginning point
    private Entity background;
    @Override
    protected void initGame() {
        /* BackgroundImage image = new BackgroundImage(new Image("file:MemoryGame/src/assets/textures/menuimage.jpg"), null, null, null, null);
        FXGL.getGameScene().a; */
        background = FXGL.entityBuilder()
            .at(0,0)
            .view("gameimage.jpg")
            .buildAndAttach();
        initCards();
    }

    public static void main(String[] args) {
        launch(args);
    }
}